everything should be self explanitory. 
set up products in products.json and settings in config.json. 

thanks for buying